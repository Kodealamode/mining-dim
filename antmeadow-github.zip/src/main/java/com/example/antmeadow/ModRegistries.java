package com.example.antmeadow;

import com.mojang.serialization.Codec;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.common.world.BiomeModifier;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModRegistries {
    private ModRegistries() {}

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, AntMeadowMod.MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, AntMeadowMod.MODID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, AntMeadowMod.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AntMeadowMod.MODID);

    public static final DeferredRegister<Codec<? extends BiomeModifier>> BIOME_MODIFIERS =
            DeferredRegister.create(ForgeRegistries.Keys.BIOME_MODIFIER_SERIALIZERS, AntMeadowMod.MODID);

    public static final RegistryObject<Codec<BoostOresModifier>> BOOST_ORES =
            BIOME_MODIFIERS.register("boost_ores", () -> BoostOresModifier.CODEC);

    public static final RegistryObject<Block> RED_ANT_COLONY = BLOCKS.register("red_ant_colony",
            () -> new RedAntColonyBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.DIRT).strength(0.8F).sound(SoundType.GRAVEL).randomTicks()));

    public static final RegistryObject<Item> RED_ANT_COLONY_ITEM = ITEMS.register("red_ant_colony",
            () -> new BlockItem(RED_ANT_COLONY.get(), new Item.Properties()));

    public static final RegistryObject<Block> DUPLICATOR_LOG = BLOCKS.register("duplicator_log",
            () -> new DuplicatorLogBlock(BlockBehaviour.Properties.copy(Blocks.OAK_LOG)));

    public static final RegistryObject<Item> DUPLICATOR_LOG_ITEM = ITEMS.register("duplicator_log",
            () -> new BlockItem(DUPLICATOR_LOG.get(), new Item.Properties()));

    public static final RegistryObject<EntityType<RedAnt>> RED_ANT = ENTITIES.register("red_ant",
            () -> EntityType.Builder.of(RedAnt::new, MobCategory.CREATURE)
                    .sized(0.5F, 0.35F).clientTrackingRange(8).build("red_ant"));

    public static final RegistryObject<Item> RED_ANT_SPAWN_EGG = ITEMS.register("red_ant_spawn_egg",
            () -> new ForgeSpawnEggItem(RED_ANT, 0xB32A1E, 0x4A0E0A, new Item.Properties()));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("ant_meadow",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.antmeadow"))
                    .icon(() -> new ItemStack(RED_ANT_COLONY_ITEM.get()))
                    .displayItems((params, out) -> {
                        out.accept(RED_ANT_COLONY_ITEM.get());
                        out.accept(RED_ANT_SPAWN_EGG.get());
                        out.accept(DUPLICATOR_LOG_ITEM.get());
                    }).build());

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
        ENTITIES.register(bus);
        TABS.register(bus);
        BIOME_MODIFIERS.register(bus);
    }
}
