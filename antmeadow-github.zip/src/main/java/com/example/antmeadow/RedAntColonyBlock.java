package com.example.antmeadow;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/** Spawns red ants around itself on random ticks, up to MAX_NEARBY_ANTS at a time. */
public class RedAntColonyBlock extends Block {
    private static final int MAX_NEARBY_ANTS = 4;

    public RedAntColonyBlock(Properties properties) {
        super(properties);
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        List<RedAnt> nearby = level.getEntitiesOfClass(RedAnt.class, new AABB(pos).inflate(12.0D));
        if (nearby.size() >= MAX_NEARBY_ANTS) return;

        for (int i = 0; i < 8; i++) {
            BlockPos spawn = pos.offset(random.nextInt(5) - 2, random.nextInt(3) - 1, random.nextInt(5) - 2);
            BlockPos below = spawn.below();
            if (level.isEmptyBlock(spawn) && level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)) {
                RedAnt ant = ModRegistries.RED_ANT.get().create(level);
                if (ant == null) return;
                ant.moveTo(spawn.getX() + 0.5D, spawn.getY(), spawn.getZ() + 0.5D, random.nextFloat() * 360.0F, 0.0F);
                ant.setPersistenceRequired();
                level.addFreshEntity(ant);
                return;
            }
        }
    }
}
