package com.example.antmeadow;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraftforge.common.ToolAction;
import net.minecraftforge.common.ToolActions;

/**
 * Looks and behaves like an oak log. The BOTTOM log of a stack duplicates any block you place next to it
 * into the 5x5 square around the log (same Y level), one block at a time, inner ring first.
 */
public class DuplicatorLogBlock extends RotatedPillarBlock {
    private static final int RADIUS = 2;        // 2 => 5x5
    private static final int DELAY_TICKS = 40;  // one duplicated block every 2 seconds

    /** 0 = none, 1..4 = which horizontal neighbour holds the block to copy (newest placement wins). */
    public static final IntegerProperty SEED = IntegerProperty.create("seed", 0, 4);

    public DuplicatorLogBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(SEED);
    }

    private boolean isBottom(BlockGetter level, BlockPos pos) {
        return !level.getBlockState(pos.below()).is(this);
    }

    private static boolean isValidSeed(BlockGetter level, BlockPos pos, BlockState s) {
        return !s.isAir()
                && !s.canBeReplaced()
                && s.getFluidState().isEmpty()
                && !(s.getBlock() instanceof DuplicatorLogBlock)
                && !s.is(BlockTags.LEAVES)
                && !s.hasProperty(BlockStateProperties.DOUBLE_BLOCK_HALF)
                && !s.hasProperty(BlockStateProperties.BED_PART)
                && s.getDestroySpeed(level, pos) >= 0.0F;
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean moved) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, moved);
        if (level.isClientSide || !isBottom(level, pos)) return;

        BlockPos diff = neighborPos.subtract(pos);
        Direction dir = Direction.fromDelta(diff.getX(), diff.getY(), diff.getZ());
        if (dir == null || dir.getAxis().isVertical()) return;

        BlockState changed = level.getBlockState(neighborPos);
        if (!isValidSeed(level, neighborPos, changed)) return;

        // A block of the type we're already copying is just one of our own duplicates arriving: ignore it.
        BlockState current = seedAt(level, pos, state);
        if (current != null && current.is(changed.getBlock())) {
            if (!level.getBlockTicks().hasScheduledTick(pos, this)) level.scheduleTick(pos, this, DELAY_TICKS);
            return;
        }
        int index = dir.get2DDataValue() + 1;
        if (state.getValue(SEED) != index) level.setBlock(pos, state.setValue(SEED, index), 2);
        if (!level.getBlockTicks().hasScheduledTick(pos, this)) level.scheduleTick(pos, this, DELAY_TICKS);
    }

    /** The block we should be copying right now, or null. */
    private BlockState seedAt(BlockGetter level, BlockPos pos, BlockState state) {
        int index = state.getValue(SEED);
        if (index > 0) {
            BlockPos p = pos.relative(Direction.from2DDataValue(index - 1));
            BlockState s = level.getBlockState(p);
            if (isValidSeed(level, p, s)) return s;
        }
        for (Direction d : Direction.Plane.HORIZONTAL) {
            BlockPos p = pos.relative(d);
            BlockState s = level.getBlockState(p);
            if (isValidSeed(level, p, s)) return s;
        }
        return null;
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!isBottom(level, pos)) return;
        BlockState seed = seedAt(level, pos, state);
        if (seed == null) return;

        List<BlockPos> inner = new ArrayList<>();
        List<BlockPos> outer = new ArrayList<>();
        for (int dx = -RADIUS; dx <= RADIUS; dx++) {
            for (int dz = -RADIUS; dz <= RADIUS; dz++) {
                if (dx == 0 && dz == 0) continue;
                BlockPos p = pos.offset(dx, 0, dz);
                BlockState there = level.getBlockState(p);
                if (!(there.isAir() || there.canBeReplaced())) continue;
                if (!seed.canSurvive(level, p)) continue;
                (Math.max(Math.abs(dx), Math.abs(dz)) == 1 ? inner : outer).add(p);
            }
        }
        List<BlockPos> pool = inner.isEmpty() ? outer : inner;
        if (pool.isEmpty()) return; // 5x5 is full

        BlockPos target = pool.get(random.nextInt(pool.size()));
        level.setBlockAndUpdate(target, seed);
        level.playSound(null, target, seed.getSoundType().getPlaceSound(), SoundSource.BLOCKS, 0.7F, 0.9F);
        level.sendParticles(ParticleTypes.HAPPY_VILLAGER, target.getX() + 0.5D, target.getY() + 0.5D, target.getZ() + 0.5D,
                4, 0.25D, 0.25D, 0.25D, 0.0D);
        level.scheduleTick(pos, this, DELAY_TICKS);
    }

    @Override
    public BlockState getToolModifiedState(BlockState state, UseOnContext context, ToolAction toolAction, boolean simulate) {
        if (toolAction == ToolActions.AXE_STRIP) {
            return Blocks.STRIPPED_OAK_LOG.defaultBlockState().setValue(AXIS, state.getValue(AXIS));
        }
        return super.getToolModifiedState(state, context, toolAction, simulate);
    }

    @Override
    public boolean isFlammable(BlockState state, BlockGetter level, BlockPos pos, Direction face) {
        return true;
    }

    @Override
    public int getFlammability(BlockState state, BlockGetter level, BlockPos pos, Direction face) {
        return 5;
    }

    @Override
    public int getFireSpreadSpeed(BlockState state, BlockGetter level, BlockPos pos, Direction face) {
        return 5;
    }
}
