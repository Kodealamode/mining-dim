package com.example.antmeadow;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(AntMeadowMod.MODID)
public class AntMeadowMod {
    public static final String MODID = "antmeadow";

    public AntMeadowMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModRegistries.register(bus);
        bus.addListener(this::onAttributes);
    }

    private void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModRegistries.RED_ANT.get(), RedAnt.createAttributes().build());
    }
}
