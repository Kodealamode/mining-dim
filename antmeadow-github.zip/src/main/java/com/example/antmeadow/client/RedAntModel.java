package com.example.antmeadow.client;

import com.example.antmeadow.AntMeadowMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

public class RedAntModel<T extends Entity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(AntMeadowMod.MODID, "red_ant"), "main");

    private static final float[] RIGHT_YAW = {-0.6F, 0.0F, 0.6F};
    private static final float[] LEFT_YAW = {0.6F, 0.0F, -0.6F};
    private static final float LEG_ROLL = 0.7F;

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart[] rightLegs = new ModelPart[3];
    private final ModelPart[] leftLegs = new ModelPart[3];

    public RedAntModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        for (int i = 0; i < 3; i++) {
            rightLegs[i] = root.getChild("right_leg" + i);
            leftLegs[i] = root.getChild("left_leg" + i);
        }
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition head = root.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, -2.0F, -4.0F, 4.0F, 4.0F, 4.0F),
                PartPose.offset(0.0F, 19.0F, -2.5F));
        CubeListBuilder antenna = CubeListBuilder.create().texOffs(34, 0).addBox(-0.5F, -4.0F, -0.5F, 1.0F, 4.0F, 1.0F);
        head.addOrReplaceChild("antenna_right", antenna, PartPose.offsetAndRotation(-1.0F, -2.0F, -4.0F, -0.5F, 0.0F, -0.25F));
        head.addOrReplaceChild("antenna_left", antenna, PartPose.offsetAndRotation(1.0F, -2.0F, -4.0F, -0.5F, 0.0F, 0.25F));

        root.addOrReplaceChild("thorax",
                CubeListBuilder.create().texOffs(16, 0).addBox(-2.0F, -2.0F, -2.5F, 4.0F, 4.0F, 5.0F),
                PartPose.offset(0.0F, 19.0F, 0.0F));
        root.addOrReplaceChild("abdomen",
                CubeListBuilder.create().texOffs(0, 12).addBox(-2.5F, -2.5F, 0.0F, 5.0F, 5.0F, 7.0F),
                PartPose.offset(0.0F, 19.5F, 2.5F));

        for (int i = 0; i < 3; i++) {
            float z = -1.5F + i * 1.5F;
            root.addOrReplaceChild("right_leg" + i,
                    CubeListBuilder.create().texOffs(0, 26).addBox(-6.0F, -0.5F, -0.5F, 6.0F, 1.0F, 1.0F),
                    PartPose.offsetAndRotation(-1.5F, 20.0F, z, 0.0F, RIGHT_YAW[i], -LEG_ROLL));
            root.addOrReplaceChild("left_leg" + i,
                    CubeListBuilder.create().texOffs(0, 26).addBox(0.0F, -0.5F, -0.5F, 6.0F, 1.0F, 1.0F),
                    PartPose.offsetAndRotation(1.5F, 20.0F, z, 0.0F, LEFT_YAW[i], LEG_ROLL));
        }
        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        head.xRot = headPitch * Mth.DEG_TO_RAD;
        float t = limbSwing * 1.4F;
        for (int i = 0; i < 3; i++) { // alternating tripod gait
            float a = Mth.cos(t + (i % 2 == 0 ? 0.0F : Mth.PI)) * 0.55F * limbSwingAmount;
            float b = Mth.cos(t + (i % 2 == 0 ? Mth.PI : 0.0F)) * 0.55F * limbSwingAmount;
            rightLegs[i].yRot = RIGHT_YAW[i] - a;
            leftLegs[i].yRot = LEFT_YAW[i] + b;
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
