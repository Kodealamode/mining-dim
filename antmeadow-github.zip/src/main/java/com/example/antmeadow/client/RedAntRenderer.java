package com.example.antmeadow.client;

import com.example.antmeadow.AntMeadowMod;
import com.example.antmeadow.RedAnt;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class RedAntRenderer extends MobRenderer<RedAnt, RedAntModel<RedAnt>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(AntMeadowMod.MODID, "textures/entity/red_ant.png");

    public RedAntRenderer(EntityRendererProvider.Context context) {
        super(context, new RedAntModel<>(context.bakeLayer(RedAntModel.LAYER)), 0.25F);
    }

    @Override
    protected void scale(RedAnt ant, PoseStack poseStack, float partialTick) {
        poseStack.scale(0.6F, 0.6F, 0.6F);
    }

    @Override
    public ResourceLocation getTextureLocation(RedAnt ant) {
        return TEXTURE;
    }
}
