package com.example.antmeadow;

import java.util.function.Function;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.portal.PortalInfo;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.util.ITeleporter;

public final class AntTravel {
    public static final ResourceKey<Level> MEADOW =
            ResourceKey.create(Registries.DIMENSION, new ResourceLocation(AntMeadowMod.MODID, "meadow"));

    private static final String RETURN_POS = "AntMeadowReturnPos";
    private static final String RETURN_DIM = "AntMeadowReturnDim";

    private AntTravel() {}

    public static void travel(ServerPlayer player) {
        if (player.level().dimension().equals(MEADOW)) {
            goHome(player);
        } else {
            enterMeadow(player);
        }
    }

    private static void enterMeadow(ServerPlayer player) {
        ServerLevel meadow = player.server.getLevel(MEADOW);
        if (meadow == null) {
            player.displayClientMessage(Component.translatable("message.antmeadow.missing"), true);
            return;
        }
        BlockPos from = player.blockPosition();
        CompoundTag data = player.getPersistentData();
        data.putLong(RETURN_POS, from.asLong());
        data.putString(RETURN_DIM, player.level().dimension().location().toString());

        // Same X/Z in the meadow, on the surface. A colony (+ one ant) is made nearby so you can get back.
        BlockPos arrival = surface(meadow, from.getX(), from.getZ());
        ensureColony(meadow, arrival);
        player.displayClientMessage(Component.translatable("message.antmeadow.enter"), true);
        player.changeDimension(meadow, new Teleporter(Vec3.atBottomCenterOf(arrival)));
    }

    private static void goHome(ServerPlayer player) {
        CompoundTag data = player.getPersistentData();
        ServerLevel target = null;
        BlockPos pos = null;
        if (data.contains(RETURN_POS) && data.contains(RETURN_DIM)) {
            ResourceLocation id = ResourceLocation.tryParse(data.getString(RETURN_DIM));
            if (id != null) target = player.server.getLevel(ResourceKey.create(Registries.DIMENSION, id));
            if (target != null) pos = BlockPos.of(data.getLong(RETURN_POS));
        }
        if (target == null) { // no saved spot (e.g. you died in there): overworld spawn
            target = player.server.overworld();
            BlockPos spawn = target.getSharedSpawnPos();
            pos = surface(target, spawn.getX(), spawn.getZ());
        }
        target.getChunk(pos);
        player.displayClientMessage(Component.translatable("message.antmeadow.leave"), true);
        player.changeDimension(target, new Teleporter(Vec3.atBottomCenterOf(pos)));
    }

    private static BlockPos surface(ServerLevel level, int x, int z) {
        level.getChunk(x >> 4, z >> 4); // make sure it is generated
        return new BlockPos(x, level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), z);
    }

    private static void ensureColony(ServerLevel level, BlockPos arrival) {
        Block colony = ModRegistries.RED_ANT_COLONY.get();
        for (BlockPos p : BlockPos.betweenClosed(arrival.offset(-8, -6, -8), arrival.offset(8, 6, 8))) {
            if (level.getBlockState(p).is(colony)) return;
        }
        BlockPos spot = surface(level, arrival.getX() + 2, arrival.getZ());
        level.setBlockAndUpdate(spot, colony.defaultBlockState());
        RedAnt ant = ModRegistries.RED_ANT.get().create(level);
        if (ant != null) {
            ant.moveTo(spot.getX() + 0.5D, spot.getY() + 1.0D, spot.getZ() + 0.5D, level.random.nextFloat() * 360.0F, 0.0F);
            ant.setPersistenceRequired();
            level.addFreshEntity(ant);
        }
    }

    private record Teleporter(Vec3 target) implements ITeleporter {
        @Override
        public PortalInfo getPortalInfo(Entity entity, ServerLevel dest, Function<ServerLevel, PortalInfo> defaultPortalInfo) {
            return new PortalInfo(target, Vec3.ZERO, entity.getYRot(), entity.getXRot());
        }
    }
}
