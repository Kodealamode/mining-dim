package com.example.antmeadow;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderSet;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.feature.OreFeature;
import net.minecraft.world.level.levelgen.feature.configurations.OreConfiguration;
import net.minecraft.world.level.levelgen.placement.CountPlacement;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.levelgen.placement.PlacementModifier;
import net.minecraftforge.common.Tags;
import net.minecraftforge.common.world.BiomeModifier;
import net.minecraftforge.common.world.ModifiableBiomeInfo;
import net.minecraftforge.server.ServerLifecycleHooks;

/**
 * Finds EVERY ore placed feature in the registry (vanilla + any mod that registers its ores as data-driven
 * placed features) and adds a copy to the target biomes that tries `multiplier` times as often.
 * Only ores that can actually replace stone/deepslate are used, so nether/end ores are skipped.
 */
public record BoostOresModifier(HolderSet<Biome> biomes, int multiplier) implements BiomeModifier {
    public static final Codec<BoostOresModifier> CODEC = RecordCodecBuilder.create(i -> i.group(
            Biome.LIST_CODEC.fieldOf("biomes").forGetter(BoostOresModifier::biomes),
            Codec.intRange(1, 32).fieldOf("multiplier").forGetter(BoostOresModifier::multiplier)
    ).apply(i, BoostOresModifier::new));

    @Override
    public void modify(Holder<Biome> biome, Phase phase, ModifiableBiomeInfo.BiomeInfo.Builder builder) {
        if (phase != Phase.ADD || !biomes.contains(biome)) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;

        Registry<PlacedFeature> registry = server.registryAccess().registryOrThrow(Registries.PLACED_FEATURE);
        for (Map.Entry<ResourceKey<PlacedFeature>, PlacedFeature> entry : registry.entrySet()) {
            if (entry.getKey().location().getNamespace().equals(AntMeadowMod.MODID)) continue;
            PlacedFeature placed = entry.getValue();
            try {
                ConfiguredFeature<?, ?> configured = placed.feature().value();
                if (!(configured.config() instanceof OreConfiguration ore) || !isOverworldOre(ore)) continue;

                List<PlacementModifier> placement = new ArrayList<>(placed.placement().size() + 1);
                placement.add(CountPlacement.of(multiplier)); // fan out N attempts, each runs the original placement
                placement.addAll(placed.placement());
                builder.getGenerationSettings().addFeature(GenerationStep.Decoration.UNDERGROUND_ORES,
                        Holder.direct(new PlacedFeature(placed.feature(), placement)));
            } catch (RuntimeException ignored) {
                // a broken/odd modded feature should never stop the dimension from loading
            }
        }
    }

    /** Ore-like block (forge:ores tag or *_ore name) that a target rule lets replace stone or deepslate. */
    private static boolean isOverworldOre(OreConfiguration ore) {
        RandomSource random = RandomSource.create(0L);
        for (OreConfiguration.TargetBlockState target : ore.targetStates) {
            if (!isOreBlock(target.state)) continue;
            if (target.target.test(Blocks.STONE.defaultBlockState(), random)
                    || target.target.test(Blocks.DEEPSLATE.defaultBlockState(), random)) {
                return true;
            }
        }
        return false;
    }

    private static boolean isOreBlock(BlockState state) {
        if (state.is(Tags.Blocks.ORES)) return true;
        ResourceLocation id = net.minecraftforge.registries.ForgeRegistries.BLOCKS.getKey(state.getBlock());
        return id != null && (id.getPath().endsWith("_ore") || id.getPath().contains("_ore_"));
    }

    @Override
    public Codec<? extends BiomeModifier> codec() {
        return CODEC;
    }
}
